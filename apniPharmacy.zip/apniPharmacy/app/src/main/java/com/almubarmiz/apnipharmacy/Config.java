package com.almubarmiz.apnipharmacy;

public class Config {
    public static final String EMAIL = "dontornato@gmail.com";
    public static final String PASSWORD = "Wael0007";
}

