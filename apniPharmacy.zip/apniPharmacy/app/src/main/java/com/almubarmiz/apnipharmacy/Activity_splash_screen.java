package com.almubarmiz.apnipharmacy;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Activity_splash_screen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
    }
}
